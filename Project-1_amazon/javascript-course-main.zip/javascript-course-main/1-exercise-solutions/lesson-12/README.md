# Exercises
![Exercises 12-final](https://user-images.githubusercontent.com/70604577/229877327-e3984d89-d53c-41e2-8f06-2b5eb0962022.png)
![Exercises 12 2-final](https://user-images.githubusercontent.com/70604577/229877331-0cdaf0c7-a031-47af-85bc-ff62b1499771.png)
![Exercises 12 3-final](https://user-images.githubusercontent.com/70604577/229877333-a9df7490-cca4-4a9b-bb72-b1aa4a17a10b.png)
![Exercises 12 4-final](https://user-images.githubusercontent.com/70604577/229877336-b9a59e69-98a2-4569-b31e-1a6b9f3e6dec.png)
![Exercises 12-part2](https://user-images.githubusercontent.com/70604577/229877401-41e73a25-bb80-4ac6-a763-a039a3ee8dce.png)
![Exercises 12-part2 2](https://user-images.githubusercontent.com/70604577/229877387-2449e79e-fed6-43f8-953b-cc508544d3f7.png)
![Exercises 12-part2 3](https://user-images.githubusercontent.com/70604577/229877391-84c33209-160c-4fac-b97b-aea0707dbf5b.png)
![Exercises 12-part2 4](https://user-images.githubusercontent.com/70604577/229877396-f1e0acda-3f24-41d2-9ee7-8935923caa55.png)
